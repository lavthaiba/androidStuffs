package com.example.k_n0012.SimpleNote.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;

import com.example.k_n0012.SimpleNote.R;
import com.example.k_n0012.SimpleNote.data.Note;
import com.example.k_n0012.SimpleNote.data.NotesDataSource;

public class NoteAddActivity extends AppCompatActivity {

    private EditText titleEditText;
    private EditText descriptionEditText;

    private NotesDataSource notesDataSource;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_add);

        notesDataSource = new NotesDataSource(this);

        titleEditText = (EditText) findViewById(R.id.activity_note_add_title);
        descriptionEditText = (EditText) findViewById(R.id.activity_note_add_description);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_note_add, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_note_add_done:
                saveNote();
                setResult(RESULT_OK);
                finish();
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void saveNote() {
        String title = titleEditText.getText().toString();
        String description = descriptionEditText.getText().toString();

        Note note = new Note(title, description);

        notesDataSource.saveNote(note);
    }
}
