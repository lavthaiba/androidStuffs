package com.example.k_n0012.SimpleNote.ui;

import com.example.k_n0012.SimpleNote.data.Note;

/**
 * Created by K-N0012 on 5/18/2017.
 */

public interface OnNoteSelectedListener {

    void onNoteSelected(Note note);


}
