package com.example.k_n0012.SimpleNote.data;

import android.provider.BaseColumns;

/**
 * Created by K-N0012 on 5/17/2017.
 */

public final class NotesDbContract {


    private NotesDbContract() {
    }


    public static final class NotesEntry implements BaseColumns {
        public static final String TABLE_NAME = "note";
        public static final String COLUMN_NAME_TITLE = "title";
        public static final String COLUMN_NAME_DESCRIPTION = "description";
    }

}