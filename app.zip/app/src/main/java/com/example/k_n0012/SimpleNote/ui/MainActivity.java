package com.example.k_n0012.SimpleNote.ui;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.example.k_n0012.SimpleNote.R;
import com.example.k_n0012.SimpleNote.data.Note;
import com.example.k_n0012.SimpleNote.data.NotesDataSource;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int NOTE_ADD_ACTIVITY_REQUEST_CODE = 1;
    private static final int NOTE_DETAILS_ACTIVITY_REQUEST_CODE = 2;

    private NotesListAdapter notesListAdapter;
    private RecyclerView recyclerView;

    private NotesDataSource notesDataSource;

    private List<Note> notes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        notesDataSource = new NotesDataSource(this);
        notes = notesDataSource.getNotes();

        recyclerView = (RecyclerView) findViewById(R.id.activity_main_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        notesListAdapter = new NotesListAdapter(notes, new OnNoteSelectedListener() {
            @Override
            public void onNoteSelected(Note note) {
                Intent intent = new Intent(getApplicationContext(), NoteDetailsActivity.class);
                intent.putExtra(NoteDetailsActivity.NOTE_EXTRA, note);
                startActivityForResult(intent, NOTE_DETAILS_ACTIVITY_REQUEST_CODE);
            }
        });
        recyclerView.setAdapter(notesListAdapter);

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(), layoutManager.getOrientation());
        recyclerView.addItemDecoration(dividerItemDecoration);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.activity_main_add_btn);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startActivityIntent = new Intent(getApplicationContext(), NoteAddActivity.class);
                startActivityIntent.putExtra("s", new Intent(getApplicationContext(), NoteDetailsActivity.class));
                startActivityForResult(startActivityIntent, NOTE_ADD_ACTIVITY_REQUEST_CODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (RESULT_OK == resultCode) {
            if (NOTE_ADD_ACTIVITY_REQUEST_CODE == requestCode || NOTE_DETAILS_ACTIVITY_REQUEST_CODE == requestCode) {
                reloadNotesAndScrollUp();
            }
        }
    }

    private void reloadNotesAndScrollUp() {
        notes = notesDataSource.getNotes();
        notesListAdapter.setNoteList(notes);
        recyclerView.smoothScrollToPosition(0);
    }
}